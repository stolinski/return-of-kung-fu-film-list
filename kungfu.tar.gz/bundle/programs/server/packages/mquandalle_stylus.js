(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:stylus'] = {};

})();

//# sourceMappingURL=mquandalle_stylus.js.map
